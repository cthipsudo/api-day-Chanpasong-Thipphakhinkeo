/* eslint-disable indent */
const BASE_URL = 'https://thinkful-list-api.herokuapp.com/oscar';

function getItems(){
    return fetch(`${BASE_URL}/items`).then(function(myRequest){
        return myRequest;
    });
    //return Promise.resolve('A successful response!');
}

function createItem(name){
    let newItem = JSON.stringify({name:name});
    
    return fetch(`${BASE_URL}/items`,{method:'POST', headers:{'Content-Type': 'application/json'}, body:newItem});
}


export default {
    getItems,
    createItem
};